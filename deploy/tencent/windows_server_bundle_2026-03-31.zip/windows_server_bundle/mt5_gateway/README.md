# MT5 Bridge Gateway

这个目录提供 MT5 账户数据网关，负责把本机 MT5 终端里的账户、持仓、交易和净值曲线整理成 Android App 可直接读取的 HTTP 接口。

## 支持模式

- `pull`
  - Python 通过 `MetaTrader5` 包直接读取本机 MT5 终端。
- `ea`
  - MT5 EA 主动把快照推送到网关。
- `auto`
  - 推荐模式；优先使用新鲜 EA 快照，不满足时回退到 Python 直连。

## API

- `GET /health`
- `GET /v1/source`
- `GET /v1/snapshot?range=1d|7d|1m|3m|1y|all`
- `GET /v1/summary?range=1d|7d|1m|3m|1y|all`
- `POST /v1/ea/snapshot`
- 完整返回结构见 `API.md`

## 1）配置

1. 复制 `.env.example` 为 `.env`
2. 至少填写这些值：
   - `MT5_LOGIN=12345678`
   - `MT5_PASSWORD=your_investor_password`
   - `MT5_SERVER=ICMarketsSC-MT5-6`
3. 建议同时确认：
   - `MT5_PATH=C:\Program Files\MetaTrader 5\terminal64.exe`
   - `MT5_SERVER_ALIASES=ICMarketsSC-MT5-6,ICMarketsSC-MT5-5,ICMarketsSC-MT5`
   - `GATEWAY_HOST=127.0.0.1`
   - `GATEWAY_PORT=8787`
   - `GATEWAY_MODE=auto`

说明：
- 如果网关前面还有 Caddy / Nginx，建议 `GATEWAY_HOST` 固定为 `127.0.0.1`，不要直接对公网暴露 `8787`。
- 这个网关只负责 MT5 账户数据；Binance 代理样例在 `deploy/tencent/` 目录。

## 2）启动

```powershell
cd bridge\mt5_gateway
.\start_gateway.ps1
```

默认本机地址：

```text
http://127.0.0.1:8787
```

如果你想指定其他环境文件：

```powershell
.\start_gateway.ps1 -EnvFile ".env"
```

## 3）EA 推送模式（可选）

1. 打开 MT5 MetaEditor
2. 导入 `bridge/mt5_gateway/ea/MT5BridgePushEA.mq5`
3. 把 EA 挂到任意图表
4. 在 MT5 中打开：
   - `Tools -> Options -> Expert Advisors`
5. 允许 WebRequest 地址：
   - `http://127.0.0.1:8787`
6. 如果 `.env` 设置了 `EA_INGEST_TOKEN`，EA 的 `BridgeToken` 也要填同一个值

## 4）App 连接方式

- 模拟器默认可直接使用：
  - `http://10.0.2.2:8787`
- 物理手机或云服务器统一入口部署时，建议改成反向代理后的地址，例如：
  - `MT5_GATEWAY_BASE_URL=http://38.190.208.20/mt5`
  - 或
  - `MT5_GATEWAY_BASE_URL=https://gateway.example.com/mt5`

修改后重新打包 APK。

## 5）腾讯云部署

完整的香港 Windows 单机部署步骤、统一公网入口代理、Caddy / Nginx 样例都在：

- `deploy/tencent/README.md`

## 说明

- 这是只读监控链路，推荐使用投资者密码
- 需要保证 MT5 终端和网关进程持续在线
- 后台常驻建议优先使用 `/v1/summary`，只有账户页和图表页再拉 `/v1/snapshot`
- 返回字段已经对齐 App 当前使用的数据结构：
  - `accountMeta`
  - `overviewMetrics`
  - `curvePoints`
  - `curveIndicators`
  - `positions`
  - `trades`
  - `statsMetrics`
